var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
var intren = {
	scrollTo: function(to) {
		var self = to;
		
		var speed = Math.abs($(document).scrollTop() - $($(self).attr('href')).offset().top);
		
		$('html, body').animate({
			scrollTop: $($(self).attr('href')).offset().top
		}, speed/2, function() {
			location.hash = $(self).attr('href');
		});
		
		return false;
	}
};

$(document).ready(function() {
	$('[data-spy="scrollTo"]').click(function() {
		return intren.scrollTo(this);
	});

	$('#map-container').gmap3({
		marker: {
			values: [
				{
					address: '1051, Budapest HercegprÃ­mÃ¡s 3',
					data: '<div class="gm-title" style="font-weight:400">AmegO Film Ltd.</div><div class="gm-addr">Budapest, HercegprÃ­mÃ¡s 3, Hungary</div>', //<div class="gm-website"><a href="https://web.archive.org/web/20141219044009/http://amegofilm.com">amegofilm.com</a></div><a href="https://web.archive.org/web/20141219044009/https://plus.google.com/u/1/103189511529514785294/about" target="_blank">More</a>'
				}
			],
			options: {
				icon: new google.maps.MarkerImage(rootUrl + "/img/base-logo-small.png", new google.maps.Size(33, 45, "px", "px"))
			},
			events:{
				click: function(marker, event, context){
					var map = $(this).gmap3("get"),
					infowindow = $(this).gmap3({get:{name:"infowindow"}});
					if (infowindow){
						infowindow.open(map, marker);
						infowindow.setContent(context.data);
					} else {
						$(this).gmap3({
							infowindow:{
								anchor:marker, 
								options:{
									content: context.data,
									maxWidth: 500,
								}
							}
						});
					}
				}
			}
		},
		map: {
			options: {
				zoom:16,
				minZoom: 4,
				scrollwheel: false,
			}
		}
	});

	$('#mixit').mixitup({
		multiFilter: true,
		filterLogic: 'and',
		onMixEnd: function() {
			var filters = [];
			var filter;

			var $activeFilters = $('.filter.active');
			if($activeFilters.length > 0) {
				$activeFilters.each(function() {
					filters.push($(this).data('filter'));
				});
				filter = filters.join('_')
			} else {
				$('.mix a').attr('data-lightbox', 'all');
				filter = "all";
				
			}

			if (filters != "") {
				$('.' + filters.join('.')).find('a').each(function() {
					var lightbox = filters.join('_');
					$(this).attr('data-lightbox', lightbox);
				});
			}
			$("document, html, body").trigger("scroll");

			countFiltered(filter);
		},
		onMixStart: function() {
			$("document, html, body").trigger("scroll");
			$('.panel').each(function() {
				var activeFilters = $(this).find('.filter.active');

				console.log(this)

				if(activeFilters.length) {
					$(this).addClass('panel-primary');
				} else {
					$(this).removeClass('panel-primary');
				}
			});
		},
		effects: ['fade']
	});
	
	$('#mixitManagement').mixitup({
		multiFilter: false,
		onMixEnd: function() {
			$("document, html, body").trigger("scroll");
		},
		onMixStart: function() {
			$("document, html, body").trigger("scroll");
		},
		effects: ['fade']
	});

	countFiltered("all");

	$('img.lasy').lazyload({
		effect: 'fadeIn'
	});

	$('#contactForm').submit(function() {
		// todo lekezelni ha hiba van.
	});

	$('.goToLink').click(function( e ) {
		document.location.href = $(this).attr('data-href');
		e.preventDefault();
	});

});

function countFiltered(lightbox) {
	if (lightbox == undefined || lightbox == "all") {
		$('.filter').each(function() {
			$(this).children('.badge').remove();
			var buttinTarget = $(this).data('filter');
			var itemsCount = $('.' + buttinTarget).length;
			
			$(this).append(' <span class="badge">' + itemsCount + '</span>');
		});
	}
	else {
		$('.filter').each(function() {
			$(this).children('.badge').remove();
			var buttinTarget = $(this).data('filter');
			var itemsCount = 0;
			$('.' + buttinTarget).each(function() {
				if ($(this).children('a').attr('data-lightbox') == lightbox) {
					itemsCount++;
				}
			});
			$(this).append(' <span class="badge">' + itemsCount + '</span>');
		});
	}
}

function initTinymce() {
	tinymce.init({
		entity_encoding: "raw",
		content_css: 'https://web.archive.org/web/20141219044009/http://fonts.googleapis.com/css?family=Oswald:400%2C700&subset=latin%2Clatin-ext,' + rootUrl + '/css/bootstrap.min.css,' + rootUrl + '/css/site.css',
		selector:'.tinymce',
		height: "250",
		menubar: false,
		statusbar: false,
		plugins: [
			"autolink lists link charmap",
			"searchreplace code fullscreen",
			"insertdatetime table contextmenu paste media"
		],
		style_formats: [
			{title: 'Header 1', block: 'h1'},
			{title: 'Header 2', block: 'h2'},
			{title: 'Header 3', block: 'h3'},
			{title: 'Header 4', block: 'h4'},
			{title: 'Header 5', block: 'h5'},
			{title: 'Header 6', block: 'h6'},
			{title: 'Lead', block: 'p', classes: 'lead'},
			{title: 'Muted', inline: 'span', classes: 'text-muted'},
		],
		toolbar: "undo redo | styleselect | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | bullist numlist | outdent indent | link media | table | fullscreen code"
	});
}
}

/*
     FILE ARCHIVED ON 04:40:09 Dec 19, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:12:35 Feb 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.832
  exclusion.robots: 0.067
  exclusion.robots.policy: 0.052
  esindex: 0.014
  cdx.remote: 16.977
  LoadShardBlock: 203.776 (3)
  PetaboxLoader3.datanode: 236.361 (4)
  PetaboxLoader3.resolve: 76.825 (2)
  load_resource: 125.347
*/